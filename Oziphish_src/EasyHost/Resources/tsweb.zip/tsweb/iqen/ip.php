<?php

function getIPs() {
    $json = file_get_contents('ip.json');
    $ips = json_decode($json, true);

    return is_array($ips) ? $ips : [];
}

function saveIPs($ips) {
    $json = json_encode($ips);
    file_put_contents('ip.json', $json);
}

$ip = isset($_POST['ip']) ? $_POST['ip'] : '';

if ($ip !== '') {
    $existingIPs = getIPs();

    if (!in_array($ip, $existingIPs)) {
        $existingIPs[] = $ip;
        saveIPs($existingIPs);
        echo 'IP added successfully.';
    } else {
        echo 'IP already exists.';
    }
} else {
    echo 'Invalid IP.';
}
?>