<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<script src="/cdn-cgi/apps/head/XrOjnlaGWlWFCsVvC73HZ0HinlY.js"></script><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
<meta name="apple-mobile-web-app-title" content="StoryZink">
<meta name="application-name" content="StoryZink">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-NCP00XZBF4"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-NCP00XZBF4');
</script>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha512-k78e1fbYs09TQTqG79SpJdV4yXq8dX6ocfP0bzQHReQSbEghnS6AQHE2BbZKns962YaqgQL16l7PkiiAHZYvXQ==" crossorigin="anonymous" />
<link rel="stylesheet" href="/src/css/style.css?v=2"><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha512-bnIvzh6FU75ZKxp0GXLH9bewza/OIw6dLVh9ICg0gogclmYGguQJWl8U30WpbsGTqbIiAwxTsbe76DErLq5EDQ==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha512-ANkGm5vSmtDaoFA/NB1nVJzOKOiI4a/9GipFtkpMG8Rg2Bz8R1GFf5kfL0+z0lcv2X/KZRugwrAlVTAgmxgvIg==" crossorigin="anonymous"></script><title>Contact Us</title>
<meta name="description" content="For any queries, suggestions. Please contact using this page."> <script src="https://kit.fontawesome.com/3e63f43eec.js" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
<a class="logo" href="https://storyzink.com/">StoryZink.com</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
<li class="nav-item dropdown" id="social-nav">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fas fa-hashtag"></i> Follow Us !
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a class="dropdown-item text-underline" href="https://fb.me/FriendshipKingCom" target="_blank">Facebook @FriendshipKingCom</a>
<a class="dropdown-item text-underline" href="https://instagram.com/friendshipking_com" target="_blank">Instagram @friendshipking_com</a>
<a class="dropdown-item text-underline" href="https://twitter.com/quizprank" target="_blank">Twitter @quizprank</a>
<a class="dropdown-item text-underline" href="https://www.getrevue.co/profile/FriendshipKing" target="_blank">Email @FriendshipKing</a>
<div class="dropdown-divider"></div>
<p class="dropdown-item">Please Follow Us to stay<br>connected!</p>
</div>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fa fa-star" aria-hidden="true"></i> Important Links
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a href="/contact-us.php" class="dropdown-item text-underline">Contact Us</a>
<a href="/disclaimer.php" class="dropdown-item text-underline">Disclaimer</a>
<a href="/privacy-policy.php" class="dropdown-item text-underline">Privacy Policy</a>
<a href="/terms.php" class="dropdown-item text-underline">Terms Of Use</a>
<a href="/cookiepolicy.php" class="dropdown-item text-underline">Cookie Policy</a>
</div>
</li>
<li class="nav-item">
<a href="/about.php" class="nav-link"><i class="fas fa-laugh-beam"></i> About Us!</a>
</li>
<li class="nav-item">
<a href="https://www.buymeacoffee.com/therohitdas" class="nav-link"><i class="fas fa-gift"></i> Support Us!</a>
</li>
</ul>
<div class="mt-2 mt-lg-0">
<a href="/index.php" class="btn btn-outline-light mr-1">Create Account</a>
<a href="/login.php" class="btn btn-outline-light ml-1">Login</a>
</div>
</div>
</nav> <div class="container" style="flex-direction: column;">
<div class="card card-2 col-12 col-sm-8 col-md-7 col-lg-6 col-xl-6 m-auto p-4">
<h3>Before sending us a mail, please read the following</h3>
<ul>
<li>If you forgot the Login PIN then please create a new account.</li>
<li>If someone is insulting you and you are bothered, please log out of your account and stop using our service.</li>
<li>If you have used a service called <strong>anonymous messages</strong>, you must understand that identity of users sending you messages are not stored. Hence, there are no ways to understand who sent you the messages.</li>
<li><strong>If someone is abusing you, there is no way from our side to understand who messaged you. I completely understand your concern but that's how our website works.</strong></li>
<li>Please read our Terms and Condition page also.</li>
<li>If someone is spamming, please create a new account.</li>
<li>If you want to delete your account, tap on the settings button in Inbox page.</li>
<li>If you want to stop receiving <strong>notifications</strong>, tap the pad lock icon ( <i class="fa fa-lock"></i> ) in the url bar on your browser and then click on <mark>site settings</mark>. Then disable push notification there. You can also search for step by step guide on google by typing <mark>disable push notification on android browser</mark>.</li>
<li><strong>In every mail, please include your link. It is important.</strong></li>
<li><strong>If you see anything unusual, then please describe it to us in the mail.</strong></li>
</ul>
<p><em>Contact us if you still have something important to say.</em><strong><br/></strong></p>
<a href="/cdn-cgi/l/email-protection#c6b2a3a7ab86b7b3afbcb6b4a7a8ade8bebfbc"><span class="__cf_email__" data-cfemail="ed99888c80ad9c9884979d9f8c8386c3959497">[email&#160;protected]</span></a>
</div>
</div>

<footer style="background: blueviolet; color: white; margin-top:10px;">

<div class="container">
<hr class="clearfix d-md-none" style="margin: 10% 15% 5%;">

<div class="row text-center d-flex justify-content-center pt-5 mb-3">

<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../terms.php" class="text-light">Terms of Use</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../about.php" class="text-light">About us</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../disclaimer.php" class="text-light">Disclaimer</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../cookiepolicy.php" class="text-light">Cookie Policy</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../privacy-policy.php" class="text-light">Privacy Policy</a>
</h6>
</div>




<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../contact-us.php" class="text-light">Contact Us</a>
</h6>
</div>

</div>

<hr class="rgba-white-light" style="margin: 0 15%;">

<div class="row d-flex text-center justify-content-center mt-1 mb-md-0 mb-4">
</div>
</div>


<div class="footer-copyright text-center py-3 " style="background-color: indigo">© 2024 Copyright:
<a href="https://storyzink.com/" class="text-light"> StoryZink.com</a>
</div>

</footer>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"848ae51ed9dfba9a","version":"2024.1.0","r":1,"token":"5e4e27d351be40c19d40a82f23c4f0ea","b":1}' crossorigin="anonymous"></script>
</body>
</html>