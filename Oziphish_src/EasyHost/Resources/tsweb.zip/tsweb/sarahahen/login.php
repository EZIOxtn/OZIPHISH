

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<script src="/cdn-cgi/apps/head/XrOjnlaGWlWFCsVvC73HZ0HinlY.js"></script><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
<meta name="apple-mobile-web-app-title" content="StoryZink">
<meta name="application-name" content="StoryZink">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-NCP00XZBF4"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-NCP00XZBF4');
</script>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha512-k78e1fbYs09TQTqG79SpJdV4yXq8dX6ocfP0bzQHReQSbEghnS6AQHE2BbZKns962YaqgQL16l7PkiiAHZYvXQ==" crossorigin="anonymous" />
<link rel="stylesheet" href="/src/css/style.css?v=2"><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha512-bnIvzh6FU75ZKxp0GXLH9bewza/OIw6dLVh9ICg0gogclmYGguQJWl8U30WpbsGTqbIiAwxTsbe76DErLq5EDQ==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha512-ANkGm5vSmtDaoFA/NB1nVJzOKOiI4a/9GipFtkpMG8Rg2Bz8R1GFf5kfL0+z0lcv2X/KZRugwrAlVTAgmxgvIg==" crossorigin="anonymous"></script><title>Login to your account</title>
<meta name="description" content></head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
<a class="logo" href="https://storyzink.com/">StoryZink.com</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
<li class="nav-item dropdown" id="social-nav">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fas fa-hashtag"></i> Follow Us !
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a class="dropdown-item text-underline" href="https://fb.me/FriendshipKingCom" target="_blank">Facebook @FriendshipKingCom</a>
<a class="dropdown-item text-underline" href="https://instagram.com/friendshipking_com" target="_blank">Instagram @friendshipking_com</a>
<a class="dropdown-item text-underline" href="https://twitter.com/quizprank" target="_blank">Twitter @quizprank</a>
<a class="dropdown-item text-underline" href="https://www.getrevue.co/profile/FriendshipKing" target="_blank">Email @FriendshipKing</a>
<div class="dropdown-divider"></div>
<p class="dropdown-item">Please Follow Us to stay<br>connected!</p>
</div>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fa fa-star" aria-hidden="true"></i> Important Links
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a href="/contact-us.php" class="dropdown-item text-underline">Contact Us</a>
<a href="/disclaimer.php" class="dropdown-item text-underline">Disclaimer</a>
<a href="/privacy-policy.php" class="dropdown-item text-underline">Privacy Policy</a>
<a href="/terms.php" class="dropdown-item text-underline">Terms Of Use</a>
<a href="/cookiepolicy.php" class="dropdown-item text-underline">Cookie Policy</a>
</div>
</li>
<li class="nav-item">
<a href="/about.php" class="nav-link"><i class="fas fa-laugh-beam"></i> About Us!</a>
</li>
<li class="nav-item">
<a href="https://www.buymeacoffee.com/therohitdas" class="nav-link"><i class="fas fa-gift"></i> Support Us!</a>
</li>
</ul>
<div class="mt-2 mt-lg-0">
<a href="/index.php" class="btn btn-outline-light mr-1">Create Account</a>
<a href="/login.php" class="btn btn-outline-light ml-1">Login</a>
</div>
</div>
</nav> <div class="container">
<div class="row">
<div class="card card-2 col-12 col-sm-8 col-md-7  col-lg-5 col-xl-4 pt-2 m-auto">
<h1 class="card-title text-center">Login to your account</h1>
<hr>
<form action method="post" name="login" id="login" style="margin-top:10px;">
<div class="form-group">
<label for="id">Your ID</label>
<input type="text" class="form-control" name="id" id="in-id" placeholder="Enter user ID" minlength="8" maxlength="32" value required>
</div>
<div class="form-group">
<label for="pin">Your PIN</label>
<input type="password" class="form-control" name="pin" id="in-pin" placeholder="Enter PIN" minlength="4" maxlength="6" value required>
</div>
<div class="form-group">
<input class="btn btn-block" type="submit" value="Login">
</div>
</form>
<p>Don't Have an account? <a href="/">Create Account</a></p>
<hr>
<h3>Help</h3>
<ul>
<li>
<strong>
Forgot pin? :
</strong> create a new account, pin is not recoverable.
</li>
<li><strong>
Forgot id? :
</strong> it is in the end of your link</li>
<li><strong>
User Id and Pin is correct, still can't login:
</strong> Use a different browser.</li>
<li><strong>
Can I use secretm.me or QuizPrank credentials here?
</strong> Yes you can use those credentials here. All three sites are synced!</li>
</ul>
</div>
</div>
</div><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"848ae53a997bba9a","version":"2024.1.0","r":1,"token":"5e4e27d351be40c19d40a82f23c4f0ea","b":1}' crossorigin="anonymous"></script>
