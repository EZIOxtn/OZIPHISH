<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<script src="/cdn-cgi/apps/head/XrOjnlaGWlWFCsVvC73HZ0HinlY.js"></script><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
<meta name="apple-mobile-web-app-title" content="StoryZink">
<meta name="application-name" content="StoryZink">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-NCP00XZBF4"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-NCP00XZBF4');
</script>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha512-k78e1fbYs09TQTqG79SpJdV4yXq8dX6ocfP0bzQHReQSbEghnS6AQHE2BbZKns962YaqgQL16l7PkiiAHZYvXQ==" crossorigin="anonymous" />
<link rel="stylesheet" href="/src/css/style.css?v=2"><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha512-bnIvzh6FU75ZKxp0GXLH9bewza/OIw6dLVh9ICg0gogclmYGguQJWl8U30WpbsGTqbIiAwxTsbe76DErLq5EDQ==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha512-ANkGm5vSmtDaoFA/NB1nVJzOKOiI4a/9GipFtkpMG8Rg2Bz8R1GFf5kfL0+z0lcv2X/KZRugwrAlVTAgmxgvIg==" crossorigin="anonymous"></script><title>Privacy Policy</title>
<meta name="description" content="At SecretM, we take online privacy seriously and we respect the concerns of our community of users. In this policy, we describe our privacy practices about the information we collect through QuizPrank.xyz and affiliated sites (the Site ), to help you make informed decisions about how you share information when you visit or use the Site."></head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
<a class="logo" href="https://storyzink.com/">StoryZink.com</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
<li class="nav-item dropdown" id="social-nav">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fas fa-hashtag"></i> Follow Us !
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a class="dropdown-item text-underline" href="https://fb.me/FriendshipKingCom" target="_blank">Facebook @FriendshipKingCom</a>
<a class="dropdown-item text-underline" href="https://instagram.com/friendshipking_com" target="_blank">Instagram @friendshipking_com</a>
<a class="dropdown-item text-underline" href="https://twitter.com/quizprank" target="_blank">Twitter @quizprank</a>
<a class="dropdown-item text-underline" href="https://www.getrevue.co/profile/FriendshipKing" target="_blank">Email @FriendshipKing</a>
<div class="dropdown-divider"></div>
<p class="dropdown-item">Please Follow Us to stay<br>connected!</p>
</div>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<i class="fa fa-star" aria-hidden="true"></i> Important Links
</a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a href="/contact-us.php" class="dropdown-item text-underline">Contact Us</a>
<a href="/disclaimer.php" class="dropdown-item text-underline">Disclaimer</a>
<a href="/privacy-policy.php" class="dropdown-item text-underline">Privacy Policy</a>
<a href="/terms.php" class="dropdown-item text-underline">Terms Of Use</a>
<a href="/cookiepolicy.php" class="dropdown-item text-underline">Cookie Policy</a>
</div>
</li>
<li class="nav-item">
<a href="/about.php" class="nav-link"><i class="fas fa-laugh-beam"></i> About Us!</a>
</li>
<li class="nav-item">
<a href="https://www.buymeacoffee.com/therohitdas" class="nav-link"><i class="fas fa-gift"></i> Support Us!</a>
</li>
</ul>
<div class="mt-2 mt-lg-0">
<a href="/index.php" class="btn btn-outline-light mr-1">Create Account</a>
<a href="/login.php" class="btn btn-outline-light ml-1">Login</a>
</div>
</div>
</nav> <div class="container" style="flex-direction: column;">
<div class="card card-2 col-12 col-sm-8 col-md-7 col-lg-6 col-xl-6 m-auto p-4">
<div data-custom-class="body">
<h1><strong>PRIVACY NOTICE</strong></h1>

<div><strong>Last updated July 21, 2022</strong></div>
<div>This privacy notice for Rohit Das ("<strong>Company</strong>," "<strong>we</strong>," "<strong>us</strong>," or
"<strong>our</strong>"), describes how and why we might collect, store, use, and/or share
("<strong>process</strong>") your information when you use our services ("<strong>Services</strong>"), such as
when you:</div>
<ul>
<li>Visit our website at <a href="https://storyzink.com" target="_blank" rel="noopener" data-custom-class="link">https://storyzink.com</a>, or any website of ours that links to this
privacy notice</li>
<li>Engage with us in other related ways ― including any sales, marketing, or events</li>
</ul>
<div><strong>Questions or concerns? </strong>Reading this privacy notice will help you understand your privacy
rights and choices. If you do not agree with our policies and practices, please do not use our Services. If you
still have any questions or concerns, please contact us at <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="177478796376746357646378656e6d7e797c3974787a">[email&#160;protected]</a>.</div>
<h2><strong>SUMMARY OF KEY POINTS</strong></h2>
<div><strong><em>This summary provides key points from our privacy notice, but you can find out more details about
any of these topics by clicking the link following each key point or by using our table of contents
below to find the section you are looking for. You can also click </em><a href="#toc" data-custom-class="link"><strong><em>here</em></strong><strong><em> to go directly to our table of
contents.</em></strong></a></strong></div>
<div>&nbsp;</div>
<div><strong>What personal information do we process?</strong> When you visit, use, or navigate our Services, we may
process personal information depending on how you interact with Rohit Das and the Services, the choices you
make, and the products and features you use. Click <a href="#personalinfo" data-custom-class="link">here</a> to
learn more.</div>
<div><strong>Do we process any sensitive personal information?</strong> We do not process sensitive personal
information.</div>
<div><strong>Do you receive any information from third parties?</strong> We do not receive any information from
third parties.</div>
<div><strong>How do you process my information?</strong> We process your information to provide, improve, and
administer our Services, communicate with you, for security and fraud prevention, and to comply with the law. We
may also process your information for other purposes with your consent. We process your information only when we
have a valid legal reason to do so. Click <a href="#infouse" data-custom-class="link">here</a> to learn more.
</div>
<div><strong>In what situations and with which parties do we share personal information? We may share information in
specific situations and with specific third parties. Click <a href="#whoshare" data-custom-class="link">here</a> to learn more. </strong></div>
<div><strong>How do we keep your information safe?</strong> We have organizational and technical processes and
procedures in place to protect your personal information. However, no electronic transmission over the internet
or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that
hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security and
improperly collect, access, steal, or modify your information. Click <a href="#infosafe" data-custom-class="link">here</a> to learn more.</div>
<div><strong>What are your rights?</strong> Depending on where you are located geographically, the applicable
privacy law may mean you have certain rights regarding your personal information. Click <a href="#privacyrights" data-custom-class="link">here</a> to learn more.</div>
<div><strong>How do I exercise my rights?</strong> The easiest way to exercise your rights is by filling out our
data subject request form available here: <a href="https://forms.gle/crqnEuKjZo1Czr5x9" target="_blank" rel="noopener" data-custom-class="link">https://forms.gle/crqnEuKjZo1Czr5x9</a>, or by contacting us. We
will consider and act upon any request in accordance with applicable data protection laws.</div>
<div>Want to learn more about what Rohit Das does with any information we collect? Click <a href="#toc" data-custom-class="link">here</a> to review the notice in full.</div>
<h3 id="toc"><strong>TABLE OF CONTENTS</strong></h3>
<div><a href="#infocollect" data-custom-class="link">1. WHAT INFORMATION DO WE COLLECT? </a></div>
<div><a href="#infouse" data-custom-class="link">2. HOW DO WE PROCESS YOUR INFORMATION? </a></div>
<div><a href="#legalbases" data-custom-class="link">3. WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR PERSONAL
INFORMATION? </a></div>
<div><a href="#whoshare" data-custom-class="link">4. WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION? </a>
</div>
<div><a href="#3pwebsites">5. WHAT IS OUR STANCE ON THIRD-PARTY WEBSITES?</a></div>
<div><a href="#cookies" data-custom-class="link">6. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES? </a></div>
<div><a href="#intltransfers" data-custom-class="link">7. IS YOUR INFORMATION TRANSFERRED INTERNATIONALLY? </a>
</div>
<div><a href="#inforetain" data-custom-class="link">8. HOW LONG DO WE KEEP YOUR INFORMATION? </a></div>
<div><a href="#infosafe" data-custom-class="link">9. HOW DO WE KEEP YOUR INFORMATION SAFE? </a></div>
<div><a href="#privacyrights" data-custom-class="link">10. WHAT ARE YOUR PRIVACY RIGHTS? </a></div>
<div><a href="#DNT" data-custom-class="link">11. CONTROLS FOR DO-NOT-TRACK FEATURES </a></div>
<div><a href="#caresidents" data-custom-class="link">12. DO CALIFORNIA RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS? </a>
</div>
<div><a href="#policyupdates" data-custom-class="link">13. DO WE MAKE UPDATES TO THIS NOTICE? </a></div>
<div><a href="#contact" data-custom-class="link">14. HOW CAN YOU CONTACT US ABOUT THIS NOTICE? </a></div>
<div><a href="#request" data-custom-class="link">15. HOW CAN YOU REVIEW, UPDATE, OR DELETE THE DATA WE COLLECT FROM
YOU?</a></div>
<div>&nbsp;</div>
<h2 id="infocollect"><strong>1. WHAT INFORMATION DO WE COLLECT?</strong></h2>
<h4 id="personalinfo"><strong>The personal information you disclose to us</strong></h4>
<div>
<div><strong><em>In Short:</em><em> We collect personal information that you provide to us.</em></strong></div>
</div>
<div>We collect personal information that you voluntarily provide to us when you register on the Services, express
an interest in obtaining information about us or our products and services, when you participate in activities
on the Services, or otherwise when you contact us.</div>
<div>&nbsp;</div>
<div><strong>Personal Information Provided by You.</strong> The personal information that we collect depends on the
context of your interactions with us and the Services, the choices you make, and the products and features you
use. The personal information we collect may include the following:</div>
<ul>
<li>names</li>
<li>email addresses</li>
<li>usernames</li>
<li>passwords</li>
<li>contact preferences</li>
<li>contact or authentication data</li>
<li>messages</li>
</ul>
<div id="sensitiveinfo"><strong>Sensitive Information.</strong> We do not process sensitive information.</div>
<div><strong>Payment Data.</strong> We may collect data necessary to process your payment if you make purchases,
such as your payment instrument number (such as a credit card number), and the security code associated with
your payment instrument.</div>
<div>All payment data is stored by</div>
<ul>
<li>PayPal - <a href="https://www.paypal.com/us/webapps/mpp/ua/privacy-full#personalData" target="_blank" rel="noopener">privacy policy</a></li>
<li>RazorPay - <a href="https://razorpay.com/privacy/" target="_blank" rel="noopener">privacy policy</a></li>
<li>Stripe - <a href="https://stripe.com/en-in/privacy" target="_blank" rel="noopener">privacy policy</a></li>
<li>Buy Me a Coffee - <a href="https://www.buymeacoffee.com/terms" target="_blank" rel="noopener">privacy
policy</a></li>
</ul>
<div>All personal information that you provide to us must be true, complete, and accurate, and you must notify us of
any changes to such personal information.</div>
<h4><strong>Information automatically collected</strong></h4>
<div>
<div><strong><em>In Short:</em><em> Some information &mdash; such as your Internet Protocol (IP) address and/or
browser and device characteristics &mdash; is collected automatically when you visit our Services.
</em></strong></div>
</div>
<div>We automatically collect certain information when you visit, use, or navigate the Services. This information
does not reveal your specific identity (like your name or contact information) but may include device and usage
information, such as your IP address, browser and device characteristics, operating system, language
preferences, referring URLs, device name, country, location, information about how and when you use our
Services, and other technical information. This information is primarily needed to maintain the security and
operation of our Services, and for our internal analytics and reporting purposes.</div>
<div>Like many businesses, we also collect information through cookies and similar technologies. You can find out
more about this in our Cookie Notice: <a href="#cookies">Cookie Notice</a>.</div>
<div>The information we collect includes:</div>
<ul>
<li><em>Log and Usage Data.</em> Log and usage data is service-related, diagnostic, usage, and performance
information our servers automatically collect when you access or use our Services and which we record in log
files. Depending on how you interact with us, this log data may include your IP address, device information,
browser type, settings and information about your activity in the Services (such as the date/time stamps
associated with your usage, pages and files viewed, searches, and other actions you take such as which
features you use), device event information (such as system activity, error reports (sometimes called "crash
dumps"), and hardware settings).</li>
<li><em>Device Data.</em> We collect device data such as information about your computer, phone, tablet, or
other device you use to access the Services. Depending on the device used, this device data may include
information such as your IP address (or proxy server), device and application identification numbers,
location, browser type, hardware model, Internet service provider and/or mobile carrier, operating system,
and system configuration information.</li>
<li><em>Location Data.</em> We collect location data such as information about your device's location, which can
be either precise or imprecise. How much information we collect depends on the type and settings of the
device you use to access the Services. For example, we may use GPS and other technologies to collect
geolocation data that tells us your current location (based on your IP address). You can opt-out of allowing
us to collect this information either by refusing access to the information or by disabling your Location
setting on your device. However, if you choose to opt-out, you may not be able to use certain aspects of the
Services.</li>
</ul>
<h2 id="infouse"><strong>2. HOW DO WE PROCESS YOUR INFORMATION?</strong></h2>
<div>
<div><strong><em>In Short: </em><em>We process your information to provide, improve, and administer our
Services, communicate with you, for security and fraud prevention, and to comply with the law. We
may also process your information for other purposes with your consent. </em></strong></div>
</div>
<div><strong>We process your personal information for a variety of reasons, depending on how you interact with our
Services, including: </strong></div>
<ul>
<li><strong>To facilitate account creation and authentication and otherwise manage user accounts. We may process
your information so you can create and log in to your account, as well as keep your account in working
order. </strong></li>
<li><strong>To deliver and facilitate the delivery of services to the user. We may process your information to
provide you with the requested service.</strong></li>
<li><strong>To respond to user inquiries/offer support to users. We may process your information to respond to
your inquiries and solve any potential issues you might have with the requested service.</strong></li>
<li><strong>To send administrative information to you. </strong>We may process your information to send you
details about our products and services, changes to our terms and policies, and other similar information.
</li>
<li><strong>To enable user-to-user communications. </strong>We may process your information if you choose to use
any of our offerings that allow for communication with another user.</li>
<li><strong>To request feedback. </strong>We may process your information when necessary to request feedback and
to contact you about your use of our Services.</li>
<li><strong>To send you marketing and promotional communications. We may process the personal information you
send to us for our marketing purposes if this is in accordance with your marketing preferences. You can
opt-out of our marketing emails at any time. For more information, see "<a href="#privacyrights" data-custom-class="link">WHAT ARE YOUR PRIVACY RIGHTS?" below). </a></strong></li>
<li><strong>To deliver targeted advertising to you.</strong> We may process your information to develop and
display personalized content and advertising tailored to your interests, location, and more. For more
information see our Cookie Notice: <a href="#cookies">Cookie Notice</a>.</li>
<li><strong>To protect our Services.</strong> We may process your information as part of our efforts to keep our
Services safe and secure, including fraud monitoring and prevention.</li>
<li><strong>To identify usage trends.</strong> We may process information about how you use our Services to
better understand how they are being used so we can improve them.</li>
<li><strong>To determine the effectiveness of our marketing and promotional campaigns. We may process your
information to better understand how to provide marketing and promotional campaigns that are most
relevant to you.</strong></li>
<li><strong>To save or protect an individual's vital interest. We may process your information when necessary to
save or protect an individual&rsquo;s vital interest, such as to prevent harm.</strong></li>
</ul>
<h2><strong>3. WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR INFORMATION? </strong></h2>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div>
<div><em><strong>In Short: </strong>We only process your
personal information when we believe it is necessary and
we have a valid legal reason (i.e., legal basis) to do
so under applicable law, like with your consent, to
comply with laws, to provide you with services to enter
into or fulfil our contractual obligations, to protect
your rights, or to fulfil our legitimate business
interests. </em></div>
<div>&nbsp;</div>
<div><em><strong><u>If you are located in the EU or UK, this
section applies to you. </u></strong></em></div>
<div>The General Data Protection Regulation (GDPR) and UK GDPR
require us to explain the valid legal bases we rely on in
order to process your personal information. As such, we may
rely on the following legal bases to process your personal
information:</div>
<ul>
<li><strong>Consent. </strong>We may process your
information if you have given us permission (i.e.,
consent) to use your personal information for a specific
purpose. You can withdraw your consent at any time.
Click <a href="#withdrawconsent" data-custom-class="link">here to learn more. </a>
</li>
<li><strong>Performance of a contract.</strong> We may
process your personal information when we believe it is
necessary to fulfil our contractual obligations to you,
including providing our Services or at your request
prior to entering into a contract with you.</li>
<li><strong>Legitimate Interests.</strong> We may process
your information when we believe it is reasonably
necessary to achieve our legitimate business interests
and those interests do not outweigh your interests and
fundamental rights and freedoms. For example, we may
process your personal information for some of the
purposes described in order to:</li>
<li>Send users information about special offers and
discounts on our products and services</li>
<li>Develop and display personalized and relevant
advertising content for our users</li>
<li>Analyze how our services are used so we can improve them
to engage and retain users</li>
<li>Support our marketing activities</li>
<li>Diagnose problems and/or prevent fraudulent activities
</li>
<li>Understand how our users use our products and services
so we can improve user experience</li>
<li><strong>Legal Obligations.</strong> We may process your
information where we believe it is necessary for
compliance with our legal obligations, such as to
cooperate with a law enforcement body or regulatory
agency, exercise or defend our legal rights, or disclose
your information as evidence in litigation in which we
are involved.</li>
<li><strong>Vital Interests.</strong> We may process your
information where we believe it is necessary to protect
your vital interests or the vital interests of a third
party, such as situations involving potential threats to
the safety of any person.</li>
</ul>
<div><strong><u><em>If you are located in Canada, this section
applies to you. </em></u></strong></div>
<div>We may process your information if you have given us
specific permission (i.e., express consent) to use your
personal information for a specific purpose, or in
situations where your permission can be inferred (i.e.,
implied consent). You can withdraw your consent at any time.
Click <a href="#withdrawconsent" data-custom-class="link">here to learn more. </a></div>
<div>&nbsp;</div>
<div>In some exceptional cases, we may be legally permitted
under applicable law to process your information without
your consent, including, for example:</div>
<ul>
<li>If collection is clearly in the interests of an
individual and consent cannot be obtained in a timely
way</li>
<li>For investigations and fraud detection and prevention
</li>
<li>For business transactions provided certain conditions
are met</li>
<li>If it is contained in a witness statement and the
collection is necessary to assess, process, or settle an
insurance claim</li>
<li>For identifying injured, ill, or deceased persons and
communicating with next of kin</li>
<li>If we have reasonable grounds to believe an individual
has been, is, or maybe a victim of financial abuse</li>
<li>If it is reasonable to expect collection and use with
consent would compromise the availability or the
accuracy of the information and the collection is
reasonable for purposes related to investigating a
breach of an agreement or a contravention of the laws of
Canada or a province</li>
<li>If disclosure is required to comply with a subpoena,
warrant, court order, or rules of the court relating to
the production of records</li>
<li>If it was produced by an individual in the course of
their employment, business, or profession and the
collection is consistent with the purposes for which the
information was produced</li>
<li>If the collection is solely for journalistic, artistic,
or literary purposes</li>
<li>If the information is publicly available and is
specified by the regulations</li>
</ul>
<h2 id="whoshare"><strong>4. WHEN AND WITH WHOM DO WE SHARE YOUR
PERSONAL INFORMATION? </strong></h2>
<div><strong><em>In Short:</em><em> We may share information in
specific situations described in this section and/or
with the following third parties. </em></strong>
</div>
<div><strong>Vendors, Consultants, and Other Third-Party Service
Providers. We may share your data with third-party
vendors, service providers, contractors, or agents
(&ldquo;<strong>third parties</strong>&rdquo;) who
perform services for us or on our behalf and require
access to such information to do that work. We have
contracts in place with our third parties, which are
designed to help safeguard your personal information.
This means that they cannot do anything with your
personal information unless we have instructed them to
do it. They will also not share your personal
information with any organization apart from us. They
also commit to protecting the data they hold on our
behalf and to retaining it for the period we instruct.
The third parties we may share personal information with
are as follows: </strong></div>
<ul>
<li><strong>Advertising, Direct Marketing, and Lead
Generation -</strong> <a href="https://valueimpression.com/privacy.html">ValueImpression</a>,
<a href="https://freestar.com/privacy-policy/" target="_blank" rel="noopener">Freestar</a>, <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google AdSense</a>,
<a href="https://policies.taboola.com/en/privacy-policy/" target="_blank" rel="noopener">Taboola</a> and <a href="https://propellerads.com/privacy/" target="_blank" rel="noopener">Propeller Ads</a>
</li>
<li><strong>Cloud Computing Services - </strong><a href="https://www.digitalocean.com/legal/privacy-policy" target="_blank" rel="noopener">DigitalOcean</a></li>
<li><strong>Communicate and Chat with Users - </strong><a href="https://www.getrevue.co/privacy">Revue</a>, <a href="https://www.facebook.com/policy.php" target="_blank" rel="noopener">Facebook Customer
Chat</a>, <a href="https://substack.com/privacy" target="_blank" rel="noopener">Substack</a>, <a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Gmail</a> and <a href="https://www.cloudflare.com/privacypolicy/" target="_blank" rel="noopener">Cloudflare</a></li>
<li><strong>Content Optimization - </strong><a href="https://policies.google.com/privacy" target="_blank" rel="noopener">Google Fonts</a> and
<a href="https://en.gravatar.com/support/data-privacy" target="_blank" rel="noopener">Gravatar</a>
</li>
<li><strong>Data Backup and Security - </strong><a href="https://policies.google.com/privacy">Google
Drive Backup</a></li>
<li><strong>Functionality and Infrastructure Optimization -
</strong><a href="https://www.digitalocean.com/legal/privacy-policy" target="_blank" rel="noopener">DigitalOcean</a> and
<a href="https://www.cloudflare.com/privacypolicy/" target="_blank" rel="noopener">Cloudflare</a>
</li>
<li><strong>Retargeting Platforms - </strong> <a href="https://www.facebook.com/policy.php">Facebook
Custom Audience</a>, <a href="https://policies.google.com/privacy">Google
Ads Remarketing</a>, <a href="https://www.facebook.com/policy.php">Facebook
Remarketing</a>, <a href="https://policies.google.com/privacy">Google
Analytics Remarketing</a></li>
<li><strong>Social Media Sharing and Advertising -
</strong><a href="https://www.addtoany.com/privacy">AddToAny</a>,
<a href="https://www.facebook.com/policy.php">Facebook
advertising</a>, <a href="https://www.facebook.com/policy.php">Facebook
social plugins</a>, <a href="https://www.facebook.com/policy.php">Instagram
advertising</a> and <a href="https://twitter.com/en/privacy">Twitter social
plugins</a>
</li>
<li><strong>User Commenting and Forums - </strong><a href="https://policies.google.com/privacy">Google
Tag Manager</a></li>
<li><strong>Web and Mobile Analytics - </strong><a href="https://www.comscore.com/About/Privacy-Policy">comScore
Analytics</a>, <a href="https://policies.google.com/privacy">Google
Analytics</a>, <a href="https://policies.google.com/privacy">Google
Tag Manager</a>, <a href="https://policies.google.com/privacy">Google
Ads</a> and <a href="https://www.quantcast.com/privacy/">Quantcast
Measure</a></li>
<li><strong>Website Performance Monitoring - </strong>Sentry
and Honeybadger</li>
<li><strong>Website Testing - </strong><a href="https://www.cloudflare.com/privacypolicy/" target="_blank" rel="noopener">Cloudflare</a></li>
<li><strong>Push Notification - </strong><a href="https://notix.co/privacy">Notix</a></li>
<li><strong>Push Notification - </strong><a href="https://www.truepush.com/privacy-policy">Truepush</a>
</li>
<li><strong>Consent Management - </strong><a href="https://www.quantcast.com/privacy/">Quantcast
Choice</a></li>
</ul>
<p><strong>You may click on the third-parties above to learn
more about their privacy policy.</strong></p>
<div>We also may need to share your personal information in the
following situations:</div>
<ul>
<li><strong>Business Transfers.</strong> We may share or
transfer your information in connection with, or during
negotiations of, any merger, sale of company assets,
financing, or acquisition of all or a portion of our
business to another company.</li>
<li><strong>Business Partners.</strong> We may share your
information with our business partners to offer you
certain products, services, or promotions.</li>
<li><strong>Other Users.</strong> When you share personal
information (for example, by posting comments,
contributions, or other content to the Services) or
otherwise interact with public areas of the Services,
such personal information may be viewed by all users and
may be publicly made available outside the Services in
perpetuity. Similarly, other users will be able to view
descriptions of your activity, communicate with you
within our Services, and view your profile.</li>
</ul>
<div>
<div>
<div>
<h2><strong>5. WHAT IS OUR STANCE ON THIRD-PARTY
WEBSITES? </strong></h2>
<div><strong><em>In Short:</em><em> We are not
responsible for the safety of any
information that you share with third
parties that we may link to or who
advertise on our Services, but are not
affiliated with, our Services.
</em></strong></div>
<div>The Services may link to third-party websites,
online services, or mobile applications and/or
contain advertisements from third parties that
are not affiliated with us and which may link to
other websites, services, or applications.
Accordingly, we do not make any guarantee
regarding any such third parties, and we will
not be liable for any loss or damage caused by
the use of such third-party websites, services,
or applications. The inclusion of a link towards
a third-party website, service, or application
does not imply an endorsement by us. We cannot
guarantee the safety and privacy of data you
provide to any third parties. Any data collected
by third parties is not covered by this privacy
notice. We are not responsible for the content
or privacy and security practices and policies
of any third parties, including other websites,
services, or applications that may be linked to
or from the Services. You should review the
policies of such third parties and contact them
directly to respond to your questions.</div>
<h2 id="cookies"><strong>6. DO WE USE COOKIES AND
OTHER TRACKING TECHNOLOGIES? </strong></h2>
<div><strong><em>In Short:</em><em> We may use
cookies and other tracking technologies
to collect and store your information.
</em></strong></div>
<div>
<h3>Cookies on our services</h3>
<p>When you use our Services, you may receive
cookies or other similar technologies such
as pixel tags (collectively,
&ldquo;Cookies&rdquo;) from us and the third
parties that collect information on our
Services.</p>
<p>A cookie is a small text file that is placed
on your computer when you visit a website.
Tracking pixels (sometimes referred to as
web beacons or clear GIFs) are tiny
electronic tags with a unique identifier
that are sometimes embedded in websites,
online ads and/or email, and that are
designed to provide usage information like
ad impressions (how many times an ad is
viewed) or clicks, to measure popularity of
the Services and associated advertising, and
to access information from user cookies.</p>
<p>Cookies can be set by either us on the site
that you visit (&ldquo;first-party
cookies&rdquo;) or a third party involved in
providing content, functionality, or
services such as analytics or advertising
for the site that you visit
(&ldquo;third-party cookies&rdquo;).</p>
<p>We use cookies to determine that we give you
a high-quality experience on our Services.
</p>
<p>We use session cookies that expire at the end
of a browser session (from when a user opens
the browser window to when they exit the
browser) and persistent cookies that remain
on your hard drive until you erase them or
they expire.</p>
<p>How long a persistent cookie remains on your
browser depends on how long the visited
website has programmed the cookie to last or
they can be stored for longer.</p>
<p>If you access our Services from your mobile
device, we may collect unique user ID, cell
phone model, operating system, and carrier.
</p>
<p>Gathering your information helps us ensure
our website and other services work
correctly and support our customer analytic
efforts.</p>
<p>We also use cookies to show you advertising
that is relevant to your interests. We may
share your information with third parties
who provide services on our behalf to help
with our business activities such as ad
technology providers, authentication
services, email service providers, data
analyzers, and business intelligence
providers for the purpose of enhancing our
products and services. These companies are
authorized to use your information only as
necessary to provide these services to us.
</p>
<p>We also may share information that has been
&ldquo;hashed&rdquo; with certain
third-party partners. &ldquo;Hashed&rdquo;
information is information that has been
converted to an anonymized string of
characters in an effort to prevent third
parties from unscrambling the anonymized
string of characters to recover the
underlying information. To opt out of our
sharing of &ldquo;hashed&rdquo; information,
please click <a href="http://www.networkadvertising.org/managing/opt_out.asp">here</a>.
</p>
<h3>Categories of cookies used on our Services
(except for UK and EEA):</h3>
<p>1. Strictly Necessary cookies. These cookies
enable you to use our Services. These
cookies are essential to enable you to
browse our Services and use certain
features. Disabling them may prevent you
from using certain parts of the Services.
Without these cookies, services such as
shopping activity and paying activity cannot
be provided. These cookies also help keep
our Services safe and secure.</p>
<p>2. Preference cookies. These cookies store
information such as your preferred country
and language selection, login data and
website preferences. Without these cookies,
our Services may not be able to remember
certain choices you've previously made (such
as a saved country / language preference) or
personalize your browsing experience by
providing you with relevant information.
These cookies can also be used to recognize
your device so that you do not have to
provide the same information more than once.
</p>
<p>3. Performance cookies. These cookies collect
information about how you use our Services
such as which pages you visit regularly.
These cookies are used to provide you with a
high-quality experience by doing things such
as tracking page load, site response times,
and error messages.</p>
<p>4. Targeting / Advertising cookies. These
cookies gather information about your use of
our Services so we may improve your
experience and provide you with more
relevant content and advertising. They are
also used to gather feedback on customer
satisfaction through surveys. They remember
that you've visited our Services and help us
understand usage of our Services. Some of
these cookies are from third parties that
collect information about users of our
Services (as described below under
"Information collected by third parties on
our Services") in order to provide
advertising (on our Services and elsewhere)
based on users&rsquo; online activities
(so-called "interest-based advertising") on
our Services and elsewhere online. The third
parties involved in interest-based
advertising collect internet browsing
information (e.g., websites visited, time of
visit) across different websites and over
time, and they may use the information they
collect on our Services to provide you ads
(from us and other companies) across the
internet.</p>
<h3>Categories of cookies used on our Services
(in UK, EU, and EEA):</h3>
<p>1. Store and/or access information on a
device. Cookies, device identifiers, or
other information can be stored or accessed
on your device for the purposes presented to
you.</p>
<p>2. Select basic ads. Ads can be shown to you
based on the content you&rsquo;re viewing,
the app you&rsquo;re using, your approximate
location, or your device type.</p>
<p>3. Create a personalised ads profile. A
profile can be built about you and your
interests to show you personalised ads that
are relevant to you.</p>
<p>4. Select personalised ads. Personalised ads
can be shown to you based on a profile about
ads that are relevant to you.</p>
<p>5. Create a personalised content profile. A
profile can be built about you and your
interests to show you personalised content
that is relevant to you.</p>
<p>6. Select personalised content. Personalised
content can be shown to you based on a
profile about you.</p>
<p>7. Measure ad performance. The performance
and effectiveness of ads that you see or
interact with can be measured.</p>
<p>8. Measure content performance. The
performance and effectiveness of content
that you see or interact with can be
measured. be measured.</p>
<p>9. Apply market research to generate audience
insights. Market research can be used to
learn more about the audiences who visit
sites/apps and view ads.</p>
<p>10. Develop and improve products. Your data
can be used to improve existing systems and
software, and to develop new products.</p>
<p>11. Ensure security, prevent fraud, and
debug. Your data can be used to monitor for
and prevent fraudulent activity, and ensure
systems and processes work properly and
securely.</p>
<p>12. Technically deliver ads or content. Your
device can receive and send information that
allows you to see and interact with ads and
content</p>
<p>13. Match and combine offline data sources.
Data from offline data sources can be
combined with your online activity in
support of one or more purposes.</p>
<p>14. Link different devices. Different devices
can be determined as belonging to you or
your household in support of one or more of
purposes.</p>
<p>15. Receive and use automatically-sent device
characteristics for identification. Your
device might be distinguished from other
devices based on information it
automatically sends, such as IP address or
browser type.</p>
<p>However, if you prefer, you can change your
cookie settings. Some browsers have options
that allow the visitor to control whether
the browser will accept cookies, reject
cookies, or notify the visitor each time a
cookie is sent. You may elect to reject
cookies by adjusting your settings, but
doing so will limit the range of features
available to you on our Services and other
major websites that use cookies. Blocking
cookies may prevent our Services from
operating as expected and may also prevent
your consent choices from being stored. That
may mean that if you opt-out, then block
cookies, we may not know about, or be able
to honor, your opt-out. You should also be
aware that blocking cookies on your computer
will not affect your consent choices on a
different device, such as a mobile device.
</p>
<p>Our Services also occasionally use "local
shared objects" (also known as "Flash
cookies"). Like browser cookies, Flash
cookies may be used for coordinating content
delivery, website functionality, maintaining
preferences, advertising, or analytics.
Unlike browser cookies, "Flash cookies" are
not stored in the browser. You may be able
to manage these Flash cookies by visiting
the Adobe <a href="https://helpx.adobe.com/flash-player/kb/disable-local-shared-objects-flash.html">website</a>.
</p>
<table border="1" width="624" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="22.916666666666668%">
<p><strong>Browser Name</strong>
</p>
</td>
<td width="43.75%">
<p><strong>Instructions</strong>
</p>
</td>
<td width="33.333333333333336%">
<p><strong>Source</strong></p>
</td>
</tr>
<tr>
<td width="22.916666666666668%">
<p>Google Chrome</p>
</td>
<td width="43.75%">
<p>Under Setting, select
"Privacy and Security",
click site settings and then
cookies. Turn Allow sites to
save and read cookie data
on/off</p>
</td>
<td width="33.333333333333336%">
<p><a href="https://support.google.com/chrome/answer/95647?">https://support.google.com/chrome/answer/95647?</a>
</p>
</td>
</tr>
<tr>
<td width="22.916666666666668%">
<p>Apple Safari</p>
</td>
<td width="43.75%">
<p>Mac: Safari&gt; Preferences,
click "Privacy"</p>
<p>&nbsp;</p>
<p>iOS: Settings&gt; Safari,
turn on "Block All Cookies"
</p>
</td>
<td width="33.333333333333336%">
<p><a href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac">https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac</a>
</p>
<p><a href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac">https://support.apple.com/en-us/HT201265</a>
</p>
</td>
</tr>
<tr>
<td width="22.916666666666668%">
<p>Mozilla Firefox</p>
</td>
<td width="43.75%">
<p>Preferences&gt; Select
"Privacy and Security" panel
and go to "Cookies and Site
Data" section.</p>
</td>
<td width="33.333333333333336%">
<p><a href="https://support.mozilla.org/en-US/kb/block-websites-storing-cookies-site-data-firefox">https://support.mozilla.org/en-US/kb/block-websites-storing-cookies-site-data-firefox</a>
</p>
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td width="22.916666666666668%">
<p>Microsoft Edge</p>
</td>
<td width="43.75%">
<p>View Advanced Settings&gt;
"Privacy and Services" &gt;
"Cookies"</p>
</td>
<td width="33.333333333333336%">
<p><a href="https://support.microsoft.com/en-us/help/4468242/microsoft-edge-browsing-data-and-privacy-microsoft-privacy">https://support.microsoft.com/en-us/help/4468242/microsoft-edge-browsing-data-and-privacy-microsoft-privacy</a>
</p>
</td>
</tr>
</tbody>
</table>
<p>Blocking cookies in your web browser may not
prevent cross-site tracking of your online
activity using other online tracking
technologies. In addition to managing your
cookie settings for your browser, you can
opt-out of tracking directly with the
businesses that operate the tracking
technologies.</p>
<p>To opt-out of certain analytic tracking by
our partners visit the links below:</p>
<table border="1" width="624" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="20%">
<p><a href="https://isapps.acxiom.com/optout/optout.aspx"><strong>Acxiom</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://extremereach.com/privacy-policy-adbridge/"><strong>Adbridg</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.amazon.com/adprefs"><strong>Amazon</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.amobee.com/trust/consumer-opt-out/"><strong>Amobee</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.scorecardresearch.com/preferences.aspx"><strong>ComScore</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://www.criteo.com/privacy/disable-criteo-services-on-internet-browsers/"><strong>Criteo</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.districtm.net/privacy-policy/"><strong>DistrictM</strong></a>
</p>
</td>
<td width="20%">
<p><a href="http://dvtemp.doubleverify.com/privacy-policy/"><strong>DoubleVerify</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.facebook.com/help/568137493302217"><strong>Facebook</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://tools.google.com/dlpage/gaoptout"><strong>Google</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://gumgum.com/opt-out"><strong>GumGum</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.indexexchange.com/privacy/"><strong>Index
Exchange</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://integralads.com/privacy-policy/"><strong>Integral
Ad Science
(IAS)</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.iqvia.com/about-us/privacy"><strong>IQVIA</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.ccc-consumercarecenter.com/UCUInternationalPage?id=a075800002r1pxMAAQ"><strong>J&amp;J</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://www.liveintent.com/ad-choices/"><strong>LiveIntent</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://liveramp.com/opt_out/"><strong>LiveRamp</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.media.net/adchoices/"><strong>Media.net</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.nativo.com/your-rights"><strong>Nativo</strong></a>
</p>
</td>
<td width="20%">
<p><a href="http://www.networkadvertising.org/managing/opt_out.asp"><strong>Neustar</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://sites.nielsen.com/legal/privacy-statement/exelate-privacy-policy/opt-in-opt-out/"><strong>Nielsen</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://datacloudoptout.oracle.com/optout"><strong>Oracle</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.openx.com/legal/privacy-policy/"><strong>OpenX</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://help.pinterest.com/en/article/personalized-ads-on-pinterest"><strong>Pinterest</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.px.com/privacy-policy/"><strong>PX</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="http://rubiconproject.com/rubicon-project-yield-optimization-privacy-policy/"><strong>Rubicon
Project</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.sailthru.com/legal/privacy-statement/"><strong>Sailthru</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://sendbird.com/privacy"><strong>SendBird</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://policies.taboola.com/en/privacy-policy/#third-party-online-advertising"><strong>Taboola</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.teads.com/privacy-policy/"><strong>Teads</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://www.thetradedesk.com/general/privacy"><strong>The
TradeDesk</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://triplelift.com/consumer-opt-out/"><strong>TripleLift</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://twitter.com/en/privacy"><strong>Twitter</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.verizonmedia.com/policies/us/en/verizonmedia/privacy/index.html"><strong>Verizon
(Oath)</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.kbmg.com/about-us/privacy/"><strong>Wunderman</strong></a>
</p>
</td>
</tr>
<tr>
<td width="20%">
<p><a href="https://www.xandr.com/privacy/platform-privacy-policy/"><strong>Xandr
(AppNexus)</strong></a>
</p>
</td>
<td width="20%">
<p><a href="https://www.yieldbot.com/platform-privacy-policy/"><strong>Yieldbot</strong></a>
</p>
</td>
<td width="20%">&nbsp;</td>
<td width="20%">&nbsp;</td>
<td width="20%">&nbsp;</td>
</tr>
</tbody>
</table>
<p>To opt out of interest-based advertising
across browsers and devices, please opt out
through the Digital Advertising Alliance or
National Advertising Institute websites, and
you also opt out through the settings within
the mobile app or your mobile device. Your
opt-out choice may apply only to the browser
or device you are using when you opt out, so
you should opt out on each of your browsers
and devices if you want to disable all
cross-device linking for interest-based
advertising. If you opt out, you will still
receive ads but they may not be as relevant
to you and your interests.</p>
<table border="1" width="624" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td width="16.826923076923077%">
<p><strong>Framework</strong>
</p>
</td>
<td width="26.602564102564102%">
<p><strong>Homepage</strong></p>
</td>
<td width="28.846153846153847%">
<p><strong>List of
Participants</strong>
</p>
</td>
<td width="27.724358974358974%">
<p><strong>Direct Link</strong>
</p>
</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>Digital Advertising Alliance
(DAA)</p>
</td>
<td width="26.602564102564102%">
<p><a href="https://youradchoices.com" target="_blank">https://youradchoices.com</a>
</p>
</td>
<td width="28.846153846153847%">
<p><a href="https://youradchoices.com/about" target="_blank">https://youradchoices.com/about</a>
</p>
</td>
<td width="27.724358974358974%">
<p><a href="http://www.networkadvertising.org/">http://www.networkadvertising.org/</a>
</p>
</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>Digital Advertising Alliance
(DAA) Canada</p>
</td>
<td width="26.602564102564102%">
<p><a href="https://youradchoices.ca">https://youradchoices.ca</a>
</p>
</td>
<td width="28.846153846153847%">
<p><a href="https://youradchoices.ca/en/participating-companies">https://youradchoices.ca/en/participating-companies</a>
</p>
</td>
<td width="27.724358974358974%">
<p><a href="http://optout.aboutads.info/?c=3&amp;lang=en/">http://optout.aboutads.info/?c=3&amp;lang=en/</a>
</p>
</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>Digital Advertising Alliance
(DAA) Australia</p>
</td>
<td width="26.602564102564102%">
<p><a href="http://youronlinechoices.com.au/">http://youronlinechoices.com.au/</a>
</p>
</td>
<td width="28.846153846153847%">
<p><a href="https://www.youronlinechoices.com.au/about-adaa/">https://www.youronlinechoices.com.au/about-adaa/</a>
</p>
</td>
<td width="27.724358974358974%">
<p><a href="http://youronlinechoices.com.au/opt-out">http://youronlinechoices.com.au/opt-out</a>
</p>
</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>Digital Advertising Alliance
(DAA) EU</p>
</td>
<td width="26.602564102564102%">
<p><a href="http://youronlinechoices.eu/">http://youronlinechoices.eu/</a>
</p>
</td>
<td width="28.846153846153847%">
&nbsp;</td>
<td width="27.724358974358974%">
&nbsp;</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>Digitust</p>
</td>
<td width="26.602564102564102%">
<p><a href="https://www.digitru.st">https://www.digitru.st</a>
</p>
</td>
<td width="28.846153846153847%">
<p><a href="https://www.digitru.st/participating-companies/">https://www.digitru.st/participating-companies/</a>
</p>
</td>
<td width="27.724358974358974%">
<p><a href="https://www.digitru.st/about-this-notice/">https://www.digitru.st/about-this-notice/</a>
</p>
</td>
</tr>
<tr>
<td width="16.826923076923077%">
<p>NAI</p>
</td>
<td width="26.602564102564102%">
<p><a href="http://www.networkadvertising.org/">http://www.networkadvertising.org/</a>
</p>
</td>
<td width="28.846153846153847%">
<p><a href="https://www.networkadvertising.org/participating-networks/">https://www.networkadvertising.org/participating-networks/</a>
</p>
</td>
<td width="27.724358974358974%">
<p><a href="http://www.networkadvertising.org/choices/">http://www.networkadvertising.org/choices/</a>
</p>
</td>
</tr>
</tbody>
</table>
<h2 id="intltransfers"><strong>7. IS YOUR
INFORMATION TRANSFERRED INTERNATIONALLY?
</strong></h2>
<div><strong><em>In Short: </em><em>We may
transfer, store, and process your
information in countries other than
your own. </em></strong></div>
<div>Our servers are located in India, and
United States. If you are accessing our
Services from outside India, and United
States, please be aware that your
information may be transferred to, stored,
and processed by us in our facilities and by
those third parties with whom we may share
your personal information (see "<a href="#whoshare" data-custom-class="link">WHEN AND WITH
WHOM DO WE SHARE YOUR PERSONAL
INFORMATION?" above), in the United
States, Cyprus, India, Thailand,
Singapore, Australia, United Kingdom,
and other countries. </a></div>
<div>If you are a resident in the European
Economic Area (EEA) or United Kingdom (UK),
then these countries may not necessarily
have data protection laws or other similar
laws as comprehensive as those in your
country. However, we will take all necessary
measures to protect your personal
information in accordance with this privacy
notice and applicable law.</div>
<div>European Commission's Standard Contractual
Clauses:</div>
<div>We have implemented measures to protect
your personal information, including by
using the European Commission's Standard
Contractual Clauses for transfers of
personal information between our group
companies and between us and our third-party
providers. These clauses require all
recipients to protect all personal
information that they process originating
from the EEA or UK in accordance with
European data protection laws and
regulations. Our Standard Contractual
Clauses can be provided upon request. We
have implemented similar appropriate
safeguards with our third-party service
providers and partners and further details
can be provided upon request.</div>
<h2 id="inforetain"><strong>8. HOW LONG DO WE
KEEP YOUR INFORMATION? </strong></h2>
<div><strong><em>In Short: </em><em>We keep your
information for as long as necessary
to fulfil the purposes outlined in
this privacy notice unless otherwise
required by law. </em></strong>
</div>
<div>We will only keep your personal information
for as long as it is necessary for the
purposes set out in this privacy notice
unless a longer retention period is required
or permitted by law (such as tax,
accounting, or other legal requirements). No
purpose in this notice will require us to
keep your personal information for longer
than thirty-six (36) months past the
termination of the user's account.</div>
<div>When we have no ongoing legitimate business
need to process your personal information,
we will either delete or anonymize such
information or, if this is not possible (for
example, because your personal information
has been stored in backup archives), then we
will securely store your personal
information and isolate it from any further
processing until deletion is possible.</div>
<h2 id="infosafe"><strong>9. HOW DO WE KEEP YOUR
INFORMATION SAFE? </strong></h2>
<div><strong><em>In Short: </em><em>We aim to
protect your personal information
through a system of organizational
and technical security measures.
</em></strong></div>
<div>We have implemented appropriate and
reasonable technical and organizational
security measures designed to protect the
security of any personal information we
process. However, despite our safeguards and
efforts to secure your information, no
electronic transmission over the Internet or
information storage technology can be
guaranteed to be 100% secure, so we cannot
promise or guarantee that hackers,
cybercriminals, or other unauthorized third
parties will not be able to defeat our
security and improperly collect, access,
steal, or modify your information. Although
we will do our best to protect your personal
information, the transmission of personal
information to and from our Services is at
your own risk. You should only access the
Services within a secure environment.</div>
<h2 id="privacyrights"><strong>10. WHAT ARE YOUR
PRIVACY RIGHTS? </strong></h2>
<div><strong><em>In Short:</em><em> In some
regions, such as the European
Economic Area (EEA), United Kingdom
(UK), and Canada, you have rights
that allow you greater access to and
control over your personal
information. You may review, change,
or terminate your account at any
time. </em></strong></div>
<div>In some regions (like the EEA, UK, and
Canada), you have certain rights under
applicable data protection laws. These may
include the right (i) to request access and
obtain a copy of your personal information,
(ii) to request rectification or erasure;
(iii) to restrict the processing of your
personal information; and (iv) if
applicable, to data portability. In certain
circumstances, you may also have the right
to object to the processing of your personal
information. You can make such a request by
contacting us by using the contact details
provided in the section &ldquo;<a href="#contact" data-custom-class="link">HOW CAN YOU
CONTACT US ABOUT THIS NOTICE?&rdquo;
below. </a></div>
<div>We will consider and act upon any request
in accordance with applicable data
protection laws.</div>
<div>If you are located in the EEA or UK and you
believe we are unlawfully processing your
personal information, you also have the
right to complain to your local data
protection supervisory authority. You can
find their contact details here: <a href="https://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm" target="_blank" rel="noopener noreferrer" data-custom-class="link">https://ec.europa.eu/justice/data-protection/bodies/authorities/index_en.htm.
</a></div>
<div>If you are located in Switzerland, the
contact details for the data protection
authorities are available here: <a href="https://www.edoeb.admin.ch/edoeb/en/home.html" target="_blank" rel="noopener noreferrer" data-custom-class="link">https://www.edoeb.admin.ch/edoeb/en/home.html.
</a></div>
<div id="withdrawconsent"><strong><u>Withdrawing
your consent: If we are relying on
your consent to process your
personal information, which may be
express and/or implied consent
depending on the applicable law, you
have the right to withdraw your
consent at any time. You can
withdraw your consent at any time by
contacting us by using the contact
details provided in the section "<a href="#contact" data-custom-class="link">HOW CAN
YOU CONTACT US ABOUT THIS
NOTICE?" below or by updating
your preferences.
</a></u></strong></div>
<div>However, please note that this will not
affect the lawfulness of the processing
before its withdrawal, nor when applicable
law allows, will it affect the processing of
your personal information conducted in
reliance on lawful processing grounds other
than consent.</div>
<div><strong><u>Opting out of marketing and
promotional communications:You can
unsubscribe from our marketing and
promotional communications at any
time by clicking on the unsubscribe
link in the emails that we send,
Blocking Notifications from your
browser settings, or by contacting
us using the details provided in the
section "<a href="#contact" data-custom-class="link">HOW CAN
YOU CONTACT US ABOUT THIS
NOTICE?" below. You will then be
removed from the marketing lists
&mdash; however, we may still
communicate with you, for
example, to send you
service-related messages that
are necessary for the
administration and use of your
account, to respond to service
requests, or for other
non-marketing purposes.
</a></u></strong></div>
<div>&nbsp;</div>
<div><strong>Account Information</strong></div>
<div>If you would at any time like to review or
change the information in your account or
terminate your account, you can:</div>
<ul>
<li>Log in to your account settings and
update your user account.</li>
<li>Contact us using the contact information
provided.</li>
</ul>
<div>Upon your request to terminate your
account, we will deactivate or delete your
account and information from our active
databases. However, we may retain some
information in our files to prevent fraud,
troubleshoot problems, assist with any
investigations, enforce our legal terms
and/or comply with applicable legal
requirements.</div>
<div><strong><u>Cookies and similar
technologies: Most Web browsers are
set to accept cookies by default. If
you prefer, you can usually choose
to set your browser to remove
cookies and to reject cookies. If
you choose to remove cookies or
reject cookies, this could affect
certain features or services of our
Services. To opt-out of
interest-based advertising by
advertisers on our Services visit <a href="http://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" data-custom-class="link">http://www.aboutads.info/choices/.
For further information, please
see our Cookie Notice: </a><a href="#cookies">Cookie
Notice</a><a href="http://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" data-custom-class="link">.
</a></u></strong></div>
<div>If you have questions or comments about
your privacy rights, you may email us at
<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="86f6f4eff0e7e5ffc6f5f2e9f4fffcefe8eda8e5e9eb">[email&#160;protected]</a>.</div>
<h2 id="DNT"><strong>11. CONTROLS FOR
DO-NOT-TRACK FEATURES </strong></h2>
<div>Most web browsers and some mobile operating
systems and mobile applications include a
Do-Not-Track ("DNT") feature or setting you
can activate to signal your privacy
preference not to have data about your
online browsing activities monitored and
collected. At this stage no uniform
technology standard for recognizing and
implementing DNT signals has been finalized.
As such, we do not currently respond to DNT
browser signals or any other mechanism that
automatically communicates your choice not
to be tracked online. If a standard for
online tracking is adopted that we must
follow in the future, we will inform you
about that practice in a revised version of
this privacy notice.</div>
<h2 id="caresidents"><strong>12. DO CALIFORNIA
RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?
</strong></h2>
<div><strong><em>In Short: </em><em>Yes, if you
are a resident of California, you
are granted specific rights
regarding access to your personal
information. </em></strong></div>
<div>California Civil Code Section 1798.83, also
known as the "Shine The Light" law, permits
our users who are California residents to
request and obtain from us, once a year and
free of charge, information about categories
of personal information (if any) we
disclosed to third parties for direct
marketing purposes and the names and
addresses of all third parties with which we
shared personal information in the
immediately preceding calendar year. If you
are a California resident and would like to
make such a request, please submit your
request in writing to us using the contact
information provided below.</div>
<div>If you are under 18 years of age, reside in
California, and have a registered account
with Services, you have the right to request
the removal of unwanted data that you
publicly post on the Services. To request
the removal of such data, please contact us
using the contact information provided below
and include the email address associated
with your account and a statement that you
reside in California. We will make sure the
data is not publicly displayed on the
Services, but please be aware that the data
may not be completely or comprehensively
removed from all our systems (e.g., backups,
etc.).</div>
<h3><strong>CCPA Privacy Notice</strong></h3>
<div>
<div>The California Code of Regulations
defines a "resident" as:</div>
</div>
<div>(1) every individual who is in the State of
California for other than a temporary or
transitory purpose and</div>
<div>(2) every individual who is domiciled in
the State of California who is outside the
State of California for a temporary or
transitory purpose</div>
<div>All other individuals are defined as
"non-residents."</div>
<div>If this definition of "resident" applies to
you, we must adhere to certain rights and
obligations regarding your personal
information.</div>
<div><strong>What categories of personal
information do we collect? </strong>
</div>
<div>We have collected the following categories
of personal information in the past twelve
(12) months:</div>
<table>
<tbody>
<tr>
<td><strong>Category</strong></td>
<td><strong>Examples</strong></td>
<td><strong>Collected</strong></td>
</tr>
<tr>
<td>
<div>A. Identifiers</div>
</td>
<td>
<div>Contact details, such as
real name, alias, postal
address, telephone or mobile
contact number, unique
personal identifier, online
identifier, Internet
Protocol address, email
address, and account name
</div>
</td>
<td>
<div data-custom-class="body_text">
YES</div>
</td>
</tr>
<tr>
<td>
<div>B. Personal information
categories listed in the
California Customer Records
statute</div>
</td>
<td>
<div>Name, contact information,
education, employment,
employment history, and
financial information</div>
</td>
<td>
<div>YES</div>
</td>
</tr>
<tr>
<td>
<div>C. Protected classification
characteristics under
California or federal law
</div>
</td>
<td>
<div>Gender and date of birth
</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>D. Commercial information
</div>
</td>
<td>
<div>Transaction information,
purchase history, financial
details, and payment
information</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>E. Biometric information
</div>
</td>
<td>
<div>Fingerprints and
voiceprints</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>F. Internet or other
similar network activity
</div>
</td>
<td>
<div>Browsing history, search
history, online behavior,
interest data, and
interactions with our and
other websites,
applications, systems, and
advertisements</div>
</td>
<td>
<div data-custom-class="body_text">
YES</div>
</td>
</tr>
<tr>
<td>
<div>G. Geolocation data</div>
</td>
<td>
<div>Device location</div>
</td>
<td>
<div data-custom-class="body_text">
YES</div>
</td>
</tr>
<tr>
<td>
<div>H. Audio, electronic,
visual, thermal, olfactory,
or similar information</div>
</td>
<td>
<div>Images and audio, video or
call recordings created in
connection with our business
activities</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>I. Professional or
employment-related
information</div>
</td>
<td>
<div>Business contact details in
order to provide you our
services at a business level
or job title, work history,
and professional
qualifications if you apply
for a job with us</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>J. Education Information
</div>
</td>
<td>
<div>Student records and
directory information</div>
</td>
<td>
<div data-custom-class="body_text">
NO</div>
</td>
</tr>
<tr>
<td>
<div>K. Inferences drawn from
other personal information
</div>
</td>
<td>
<div>Inferences drawn from any
of the collected personal
information listed above to
create a profile or summary
about, for example, an
individual&rsquo;s
preferences and
characteristics</div>
</td>
<td>
<div data-custom-class="body_text">
YES</div>
</td>
</tr>
</tbody>
</table>
<div>We may also collect other personal
information outside of these categories
instances where you interact with us in
person, online, or by phone or mail in the
context of:</div>
<ul>
<li>Receiving help through our customer
support channels;</li>
<li>Participation in customer surveys or
contests; and</li>
<li>Facilitation in the delivery of our
Services and to respond to your
inquiries.</li>
</ul>
<div><strong>How do we use and share your
personal information? </strong></div>
<div>Rohit Das collects and shares your personal
information through:</div>
<ul>
<li>Targeting cookies/Marketing cookies</li>
<li>Social media cookies</li>
<li>Beacons/Pixels/Tags</li>
<li>Social media plugins: Facebook Social
Plugins, AddToAny and Tweet Button. We
use social media features, such as a
"Like" button, and widgets, such as a
"Share" button in our Services. Such
features may process your Internet
Protocol (IP) address and track which
page you are visiting on our website. We
may place a cookie to enable the feature
to work correctly. If you are logged in
on a certain social media platform and
you interact with a widget or button
belonging to that social media platform,
this information may be recorded to your
profile of such social media platform.
To avoid this, you should log out from
that social media platform before
accessing or using the Services. Social
media features and widgets may be hosted
by a third party or hosted directly on
our Services. Your interactions with
these features are governed by the
privacy notices of the companies that
provide them. By clicking on one of
these buttons, you agree to the use of
this plugin and consequently the
transfer of personal information to the
corresponding social media service. We
have no control over the essence and
extent of these transmitted data or
their additional processing.</li>
</ul>
<div>
<div>More information about our data
collection and sharing practices can be
found in this privacy notice and our
Cookie Notice: <a href="#cookies">Cookie
Notice</a>.</div>
<div>&nbsp;</div>
<div>You can opt-out from the selling of
your personal information by disabling
cookies in Cookie Preference Settings
and clicking on the Do Not Sell My
Personal Information link on our
homepage.</div>
<div>&nbsp;</div>
<div>You may contact us by email at
<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ee8d8d9e8fae9d9a819c9794878085c08d8183">[email&#160;protected]</a>, or by referring
to the contact details at the bottom of
this document.</div>
<div>&nbsp;</div>
<div>If you are using an authorized agent to
exercise your right to opt-out we may
deny a request if the authorized agent
does not submit proof that they have
been validly authorized to act on your
behalf.</div>
<div>&nbsp;</div>
<div><strong>Will your information be shared
with anyone else? </strong></div>
<div>We may disclose your personal
information with our service providers
pursuant to a written contract between
us and each service provider. Each
service provider is a for-profit entity
that processes the information on our
behalf.</div>
<div>We may use your personal information
for our own business purposes, such as
for undertaking internal research for
technological development and
demonstration. This is not considered to
be "selling" of your personal
information.</div>
<div>Rohit Das has disclosed the following
categories of personal information to
third parties for a business or
commercial purpose in the preceding
twelve (12) months:</div>
<ul>
<li>Category A. Identifiers, such as
contact details like your real name,
alias, postal address, telephone or
mobile contact number, unique
personal identifier, online
identifier, Internet Protocol
address, email address, and account
name.</li>
<li>Category B. Personal information, as
defined in the California Customer
Records law, such as your name,
contact information, education,
employment, employment history, and
financial information.</li>
<li>Category F. Internet or other
electronic network activity
information, such as browsing
history, search history, online
behaviour, interest data, and
interactions with our and other
websites, applications, systems, and
advertisements.</li>
<li>Category G. Geolocation data, such
as device location.</li>
<li>Category K. Inferences are drawn
from any of the personal information
listed above to create a profile or
summary about, for example, an
individual's preferences and
characteristics.</li>
</ul>
<div>
<div>
<div>
<div>
<div>
<div>The categories of
third parties to
whom we disclosed
personal information
for a business or
commercial purpose
can be found under
"<a href="#whoshare" data-custom-class="link">WHEN
AND WITH WHOM DO
WE SHARE YOUR
PERSONAL
INFORMATION?".
</a></div>
<div>Rohit Das has sold
the following
categories of
personal information
to third parties in
the preceding twelve
(12) months:</div>
<ul>
<li>Category A.
Identifiers,
such as contact
details, like
your real name,
alias, postal
address,
telephone or
mobile contact
number, unique
personal
identifier,
online
identifier,
Internet
Protocol
address, email
address, and
account name.
</li>
<li>Category B.
Personal
information, as
defined in the
California
Customer Records
law, such as
your name,
contact
information,
education,
employment,
employment
history, and
financial
information.
</li>
<li>Category F.
Internet or
other electronic
network activity
information,
such as browsing
history, search
history, online
behaviour,
interest data,
and interactions
with our and
other websites,
applications,
systems, and
advertisements.
</li>
<li>Category G.
Geolocation
data, such as
device location.
</li>
<li>Category K.
Inferences are
drawn from any
of the personal
information
listed above to
create a profile
or summary
about, for
example, an
individual's
preferences and
characteristics.
</li>
</ul>
<div>The categories of
third parties to
whom we sold
personal information
are:</div>
<ul>
<li><strong>Advertising,
Direct
Marketing,
and Lead
Generation -
</strong>Freestar,
Google AdSense,
Taboola and
Propeller Ads
</li>
<li><strong>Retargeting
Platforms -
</strong>Criteo
Dynamic
Retargeting,
Facebook Custom
Audience, Google
Ads Remarketing,
Facebook
Remarketing,
Google Analytics
Remarketing and
Twitter
Remarketing</li>
<li><strong>Social
Media
Sharing and
Advertising
-
</strong>AddToAny,
Facebook
advertising,
Facebook social
plugins,
Instagram
advertising,
PayPal plugins
and Twitter
social plugins
</li>
<li><strong>Web and
Mobile
Analytics -
</strong>comScore
Analytics,
Google
Analytics,
Google Tag
Manager, Google
Ads and
Quantcast
Measure</li>
</ul>
<div><strong>Your rights
with respect to
your personal
data </strong>
</div>
<div><u>Right to request
deletion of the
data &mdash;
Request to
delete </u>
</div>
<div>You can ask for the
deletion of your
personal
information. If you
ask us to delete
your personal
information, we will
respect your request
and delete your
personal
information, subject
to certain
exceptions provided
by law, such as (but
not limited to) the
exercise by another
consumer of his or
her right to free
speech, our
compliance
requirements
resulting from a
legal obligation, or
any processing that
may be required to
protect against
illegal activities.
</div>
<div><u>Right to be
informed &mdash;
Request to know
</u></div>
<div>Depending on the
circumstances, you
have a right to
know:</div>
<ul>
<li>whether we
collect and use
your personal
information;
</li>
<li>the categories
of personal
information that
we collect;</li>
<li>the purposes for
which the
collected
personal
information is
used;</li>
<li>whether we sell
your personal
information to
third parties;
</li>
<li>the categories
of personal
information that
we sold or
disclosed for a
business
purpose;</li>
<li>the categories
of third parties
to whom the
personal
information was
sold or
disclosed for a
business
purpose; and
</li>
<li>the business or
commercial
purpose for
collecting or
selling personal
information.
</li>
</ul>
<div>In accordance with
applicable law, we
are not obligated to
provide or delete
consumer information
that is
de-identified in
response to a
consumer request or
to re-identify
individual data to
verify a consumer
request.</div>
<div><u>Right to
Non-Discrimination
for the Exercise
of a
Consumer&rsquo;s
Privacy Rights
</u></div>
<div>We will not
discriminate against
you if you exercise
your privacy rights.
</div>
<div><u>Verification
process</u>
</div>
<div>Upon receiving your
request, we will
need to verify your
identity to
determine you are
the same person
about whom we have
the information in
our system. These
verification efforts
require us to ask
you to provide
information so that
we can match it with
the information you
have previously
provided us. For
instance, depending
on the type of
request you submit,
we may ask you to
provide certain
information so that
we can match the
information you
provide with the
information we
already have on
file, or we may
contact you through
a communication
method (e.g., phone
or email) that you
have previously
provided to us. We
may also use other
verification methods
as the circumstances
dictate.</div>
<div>We will only use
the personal
information provided
in your request to
verify your identity
or authority to make
the request. To the
extent possible, we
will avoid
requesting
additional
information from you
for the purposes of
verification.
However, if we
cannot verify your
identity from the
information already
maintained by us, we
may request that you
provide additional
information for the
purposes of
verifying your
identity and for
security or fraud
prevention purposes.
We will delete such
additionally
provided information
as soon as we finish
verifying you.</div>
<div><u>Other privacy
rights</u></div>
<ul>
<li>You may object
to the
processing of
your personal
information.
</li>
<li>You may request
correction of
your personal
data if it is
incorrect or no
longer relevant,
or ask to
restrict the
processing of
the information.
</li>
<li>You can
designate an
authorized agent
to make a
request under
the CCPA on your
behalf. We may
deny a request
from an
authorized agent
that does not
submit proof
that they have
been validly
authorized to
act on your
behalf in
accordance with
the CCPA.</li>
</ul>
<div>
<div>To exercise
these rights,
you can contact
us by email at
<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="b9dadac9d8f9cacdd6cbc0c3d0d7d297dad6d4">[email&#160;protected]</a>,
or by referring
to the contact
details at the
bottom of this
document. If you
have a complaint
about how we
handle your
data, we would
like to hear
from you.</div>
<h2 id="policyupdates">
<strong>13. DO
WE MAKE
UPDATES TO
THIS NOTICE?
</strong>
</h2>
<div><em><strong>In
Short:
Yes, we
will
update
this
notice
as
necessary
to stay
compliant
with
relevant
laws.
</strong></em>
</div>
<div>We may update
this privacy
notice from time
to time. The
updated version
will be
indicated by an
updated
"Revised" date
and the updated
version will be
effective as
soon as it is
accessible. If
we make material
changes to this
privacy notice,
we may notify
you either by
prominently
posting a notice
of such changes
or by directly
sending you a
notification. We
encourage you to
review this
privacy notice
frequently to be
informed of how
we are
protecting your
information.
</div>
<h2 id="contact">
<strong>14. HOW
CAN YOU
CONTACT US
ABOUT THIS
NOTICE?
</strong>
</h2>
<div>If you have
questions or
comments about
this notice, you
may email us at
<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="d2a2a0bba4b3b1ab92a1a6bda0aba8bbbcb9fcb1bdbf">[email&#160;protected]</a>
</div>
<h2 id="request">
<strong>15. HOW
CAN YOU
REVIEW,
UPDATE, OR
DELETE THE
DATA WE
COLLECT FROM
YOU?
</strong>
</h2>
<div>Based on the
applicable laws
of your country,
you may have the
right to request
access to the
personal
information we
collect from
you, change that
information, or
delete it in
some
circumstances.
We use Quantcast
to manage your
consent. Use
this link to
access and
control who can
process your
data: <a href="#" onclick="event.preventDefault(); window.__tcfapi('displayConsentUi', 2, function() {} );">Consent
Manager</a>.
To request to
review, update,
or delete your
personal
information,
please visit: <a href="https://forms.gle/crqnEuKjZo1Czr5x9" target="_blank" rel="noopener" data-custom-class="link">https://forms.gle/crqnEuKjZo1Czr5x9.
</a></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<footer style="background: blueviolet; color: white; margin-top:10px;">

<div class="container">
<hr class="clearfix d-md-none" style="margin: 10% 15% 5%;">

<div class="row text-center d-flex justify-content-center pt-5 mb-3">

<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../terms.php" class="text-light">Terms of Use</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../about.php" class="text-light">About us</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../disclaimer.php" class="text-light">Disclaimer</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../cookiepolicy.php" class="text-light">Cookie Policy</a>
</h6>
</div>


<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../privacy-policy.php" class="text-light">Privacy Policy</a>
</h6>
</div>




<div class="col-md-2 mb-3">
<h6 class="text-uppercase font-weight-bold">
<a href="../../contact-us.php" class="text-light">Contact Us</a>
</h6>
</div>

</div>

<hr class="rgba-white-light" style="margin: 0 15%;">

<div class="row d-flex text-center justify-content-center mt-1 mb-md-0 mb-4">
</div>
</div>


<div class="footer-copyright text-center py-3 " style="background-color: indigo">© 2024 Copyright:
<a href="https://storyzink.com/" class="text-light"> StoryZink.com</a>
</div>

</footer>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"848ae4fc7f98ba9a","version":"2024.1.0","r":1,"token":"5e4e27d351be40c19d40a82f23c4f0ea","b":1}' crossorigin="anonymous"></script>
</body>
</html>